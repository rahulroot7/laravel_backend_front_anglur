app.controller('SingleProfileController', function($scope,$http,config,$routeParams) {
   $scope.showLoader = true;
    $scope.noresult = false;
    $scope.Adress = "American University,4400 Massachusetts Ave NW,Washington, DC 20016";
     $scope.opendetail = function (evt,activity) {
       var i, singletabcontent, singletablinks;
      singletabcontent = document.getElementsByClassName("singletabcontent");
      for (i = 0; i < singletabcontent.length; i++) {
        singletabcontent[i].style.display = "none";
      }
      singletablinks = document.getElementsByClassName("singletablinks");
      for (i = 0; i < singletablinks.length; i++) {
        singletablinks[i].className = singletablinks[i].className.replace(" active", "");
      }
      
      document.getElementById(activity).style.display = "block";
      evt.className += " active"; 
};
$http({
          method: 'GET',
          url:  config.apiURL+'single-advisor/'+$routeParams.id
       }).then(function (response){
            $scope.showLoader = false;
             data = response.data;
             if(data.status == 200){
                 if(data.data.length > 0){
                     $scope.profile = data.data[0];
                 }else{
                     $scope.profile = '';
                 }
                 
             }else{
                $scope.noresult = true; 
             }
             
       },function (error){
           $scope.showLoader = false;
             console.log(error);
       });
});


