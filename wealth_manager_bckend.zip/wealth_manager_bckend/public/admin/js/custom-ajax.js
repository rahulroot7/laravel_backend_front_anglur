
jQuery(document).ready(function () {
    //check if firm_name is OTHER
    jQuery("#firm_name").on('change', function () {
        var firm_name = jQuery("#firm_name").val();
        if (firm_name == "Other") {
            jQuery(".add_firm_form").show();
        } else {
            jQuery(".add_firm_form").hide();
        }
    });

    //Ajax code for show member list according to firm name
    $(document).on("change", ".choose_firm_name", function (e) {
        e.preventDefault();
        var _token = $("input[name='_token']").val();
        var firm_id = $(this).val();

        //set all val
        var options = { "_token": _token, "firm_id": firm_id };

        $.ajax({
            type: "GET",
            url: base_url + "/assign-manage-member-list",
            context: this,
            data: options,
            beforeSend: function () {
                $(".custom_loader").show();
            },
            success: function (responce) {
                $(".assign_member_list_reponce").html(responce);
                $(".custom_loader").hide();
                setTimeout(function () {
                    $(".success-msg").fadeOut(3000);
                    $(".unsuccess-msg").fadeOut(3000);
                }, 3000);
            }
        });
    });

    //Ajax code for select_country_name
    $(document).on("change", ".select_country_name", function (e) {
        e.preventDefault();
        var _token = $("input[name='_token']").val();
        var country_id = $(this).val();

        //set all val
        var options = { "_token": _token, "country_id": country_id };

        $.ajax({
            type: "GET",
            url: base_url + "/show-country-states",
            context: this,
            data: options,
            beforeSend: function () {
                // $(".custom_loader").show();
            },
            success: function (responce) {
                $('.select_state_name').html(responce);
                // $(".custom_loader").hide();
            }
        });
    });

    //Ajax code for add_select_country_name
    $(document).on("change", ".add_select_country_name", function (e) {
        e.preventDefault();
        var _token = $("input[name='_token']").val();
        var country_code = $(this).val();

        //set all val
        var options = { "_token": _token, "country_code": country_code };

        $.ajax({
            type: "GET",
            url: base_url + "/show-states-according-country",
            context: this,
            data: options,
            beforeSend: function () {
                // $(".custom_loader").show();
            },
            success: function (responce) {
                $('.add_select_state_name').html(responce);
                // $(".custom_loader").hide();
            }
        });
    });

    //Ajax code for add_select_state_name
    $(document).on("change", ".add_select_state_name", function (e) {
        e.preventDefault();
        var _token = $("input[name='_token']").val();
        var state_code = $(this).val();
    
        //set all val
        var options = { "_token": _token, "state_code": state_code };

        $.ajax({
            type: "GET",
            url: base_url + "/show-cities-according-state",
            context: this,
            data: options,
            beforeSend: function () {
                // $(".custom_loader").show();
            },
            success: function (responce) {
                $('.add_select_city_name').html(responce);
                // $(".custom_loader").hide();
            }
        });
    });
});