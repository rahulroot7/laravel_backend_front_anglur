app.controller('FilterresultController', function($scope,$http,config,$routeParams,$location,$rootScope,$timeout,$sce) {
    
    $scope.showfilterLoader = true;  
  
    $scope.filterresults = [];
    $scope.membership_services = [];
    
    $scope.searchlocation = '';
    $scope.servicename = '';
    $scope.city_name = '';
    $scope.state_name = '';
    $scope.designation_name = '';
    $scope.firm_name = '';
    $scope.member_name = '';
    $scope.lastSearchname = '';
   
    $scope.services =[];
    $scope.selected = [];
    $scope.statelist = [];
    $scope.selectedType = '';
    
    
    
    $scope.lastSearchTerm = null;
    $scope.currentIndex = null;
    $scope.justChanged = false;
    $scope.searchTimer = null;
    $scope.hideTimer = null;
    $scope.searching = false;
    $scope.clearfilter = false;
    $scope.pause = 500;
    $scope.minLength = 3;
    $scope.searchStr = null;
    $scope.matchClass = 'highlight';
    $scope.titleField = 'location';
    
    $scope.currentPage = 1;   
    $scope.pageSize = 5;
    
    init();
  
    function init() {
    
   $scope.fetchRequest= function($currentpage){
     $scope.showfilterLoader = true;
     if($routeParams.state_name !== undefined){
        $scope.state_name = $routeParams.state_name;
    }
    if($routeParams.city_name !== undefined){
        $scope.city_name = $routeParams.city_name;
    }  
    
    if($routeParams.service_name !== undefined){
      $scope.servicename = $routeParams.service_name;
    }
    if($routeParams.member_name !== undefined){
          $scope.member_name = $routeParams.member_name;
          $scope.lastSearchname =  $scope.member_name;
    }
    if($routeParams.firm_name !== undefined){
          $scope.firm_name = $routeParams.firm_name;
    }
    if($routeParams.designation_name !== undefined){
         $scope.designation_name = $routeParams.designation_name;
    }
    if( $scope.servicename !== ''){
         $scope.services =$scope.servicename.split(',');
         $scope.selected =  $scope.services;
    }
    if($routeParams.location_name !== undefined){
         $scope.searchlocation = $routeParams.location_name;
          $scope.searchStr =   $scope.searchlocation;
    }
    $http({
              method: 'GET',
              url: config.apiURL+'filter-result?city_name='+ $scope.city_name+'&state_name='+$scope.state_name+'&designation_name='+$scope.designation_name+'&member_name='+$scope.member_name+'&firm_name='+$scope.firm_name+'&service_name='+$scope.servicename+'&location_name='+$scope.searchlocation+'&page='+$currentpage
           }).then(function (response){
                 data = response.data;
                 if(data.status == 200){
                   $scope.viewing_agent_count = data.data.viewing_agent_count;
                   $scope.totalrecords = data.data.member_list_total;
                   $scope.filterresults = data.data.member_list;
                   $scope.pager = $scope.GetPager($scope.totalrecords,$currentpage);
                 }else{
                     $scope.filterresults = data.data;
                     $scope.viewing_agent_count = 0;
                     $scope.totalrecords = 0
                 }
                  $scope.showfilterLoader = false;
           },function (error){
                $scope.showfilterLoader = false;
           });
   }  
    $scope.CallAPIRequest= function(membername,firmname,designationname,cityname,statename,servicename,searchlocation,currentPage){
        $scope.showfilterLoader = true;
        currentPage = currentPage || 1;
        cityname = cityname || '';
        statename = statename || '';
        servicename = servicename || '';
        membername = membername || '';
        firmname = firmname || '';
        designationname = designationname || '';
        searchlocation = searchlocation || '';
        $http({
              method: 'GET',
              url: config.apiURL+'filter-result?city_name='+cityname+'&state_name='+statename+'&service_name='+servicename+'&member_name='+membername+'&firm_name='+firmname+'&designation_name='+designationname+'&location_name='+searchlocation+'&page='+currentPage
           }).then(function (response){
                 data = response.data;
                 if(data.status == 200){
                   $scope.viewing_agent_count = data.data.viewing_agent_count;
                   $scope.totalrecords = data.data.member_list_total;
                   $scope.filterresults = data.data.member_list;
                   $scope.pager = $scope.GetPager($scope.totalrecords,currentPage);
                 }else{
                     $scope.filterresults = data.data;
                     $scope.viewing_agent_count = 0;
                     $scope.totalrecords = 0
                 }
                  $scope.showfilterLoader = false;
           },function (error){
                $scope.showfilterLoader = false;
           });
    }
    
    /*********Pagination function start**********/
    $scope.numberOfPages= function(){
        return Math.ceil($scope.totalrecords/$scope.pageSize);                
    }
    
    $scope.setPage = function($page){
         if ($page < 1 || $page > $scope.numberOfPages()) {
                return;
            }
        $scope.currentPage = $page; 
        $scope.CallAPIRequest($scope.member_name,$scope.firm_name,$scope.designation_name,$scope.city_name,$scope.state_name,$scope.services.toString(),$scope.searchlocation,$scope.currentPage);
    }
    $scope.range = function(min, max, step){
        step = step || 1;
        var input = [];
        for (var i = min; i <= max; i += step) input.push(i);
        return input;
      };
    $scope.GetPager = function(totalItems, currentPage, pageSize){
         // default to first page
            currentPage = currentPage || 1;

            // default page size is 10
            pageSize = pageSize || 5;

            // calculate total pages
            var totalPages = Math.ceil(totalItems / pageSize);
            var startPage, endPage;
            if (totalPages <= 10) {
                // less than 10 total pages so show all
                startPage = 1;
                endPage = totalPages;
            } else {
                // more than 10 total pages so calculate start and end pages
                if (currentPage <= 6) {
                    startPage = 1;
                    endPage = 10;
                } else if (currentPage + 4 >= totalPages) {
                    startPage = totalPages - 9;
                    endPage = totalPages;
                } else {
                    startPage = currentPage - 5;
                    endPage = currentPage + 4;
                }
            }

            // calculate start and end item indexes
            var startIndex = (currentPage - 1) * pageSize;
            var endIndex = Math.min(startIndex + pageSize - 1, totalItems - 1);

            // create an array of pages to ng-repeat in the pager control
            var pages = $scope.range(startPage, endPage );

            // return object with all pager properties required by the view
            return {
                totalItems: totalItems,
                currentPage: currentPage,
                pageSize: pageSize,
                totalPages: totalPages,
                startPage: startPage,
                endPage: endPage,
                startIndex: startIndex,
                endIndex: endIndex,
                pages: pages
            };
        }
   /*********Pagination function End**********/
  /*********** sidebar **************/       
   $http({
              method: 'GET',
              url: config.apiURL+'sidebar-filter-result'
           }).then(function (response){
                 data = response.data;
                 if(data.status == 200){
                    $scope.sidebarresult = data.data;
                    $scope.membership_services = data.data.member_service_list;
                    $scope.fetchRequest($scope.currentPage);
                 }
                 
           },function (error){
                $scope.showsidefilterLoader = false;
                 console.log(error);
           });
 
    $scope.callfilter = function ($servicename) {
        var idx = $scope.selected.indexOf($servicename);
        if(idx > -1){
            $scope.selected.splice(idx,1);  
        }else{
           $scope.selected.push($servicename);  
        }
       
        var allservices =  $scope.selected.toString();
        $scope.CallAPIRequest($scope.member_name,$scope.firm_name,$scope.designation_name,$scope.city_name,$scope.state_name,allservices,$scope.searchlocation,$scope.currentPage);
        $location.path('filter-result',false).search('service_name', allservices,1);
    }; 
  
    $scope.callfirm = function() {

        $scope.CallAPIRequest($scope.member_name,$scope.firm_name,$scope.designation_name,$scope.city_name,$scope.state_name.state_sort_name,$scope.services.toString(),$scope.searchlocation,$scope.currentPage);
        $location.path('filter-result',false).search('firm_name', $scope.firm_name);
    }
    
      $scope.calldesignation = function(designation_name) {
          console.log(designation_name);
        
        $scope.designation_name='';
        $scope.designation_name = designation_name;
        if($scope.designation_name === undefined){
             $scope.designation_name='';
        }
        
        $scope.CallAPIRequest($scope.member_name,$scope.firm_name,$scope.designation_name,$scope.city_name,$scope.state_name.state_sort_name,$scope.services.toString(),$scope.searchlocation,$scope.currentPage);
        $location.path('filter-result',false).search('designation_name', $scope.designation_name);
    }
   
      $scope.callmembername = function() {
         if($scope.member_name !== ''){
            $scope.lastSearchname = $scope.member_name;
            $scope.CallAPIRequest($scope.member_name,$scope.firm_name,$scope.designation_name,$scope.city_name,$scope.state_name.state_sort_name,$scope.services.toString(),$scope.searchlocation,$scope.currentPage);
                $location.path('filter-result',false).search('member_name', $scope.member_name);
         }else if($scope.lastSearchname !== ''){
             $scope.lastSearchname = $scope.member_name;
             $scope.CallAPIRequest($scope.member_name,$scope.firm_name,$scope.designation_name,$scope.city_name,$scope.state_name.state_sort_name,$scope.services.toString(),$scope.searchlocation,$scope.currentPage);
                $location.path('filter-result',false).search('member_name', $scope.member_name);
         }
        
    }
  
    $scope.checkKeyUp = function(event){
         if (!(event.which == 38 || event.which == 40 || event.which == 13)) {
                    if (!$scope.searchStr || $scope.searchStr == "") {
                        $scope.showDropdown = false;
                        $scope.lastSearchTerm = null
                    } else if (isNewSearchNeeded($scope.searchStr, $scope.lastSearchTerm)) {
                        $scope.lastSearchTerm = $scope.searchStr
                        $scope.showDropdown = true;
                        $scope.currentIndex = -1;
                        $scope.results = [];

                        if ($scope.searchTimer) {
                            $timeout.cancel($scope.searchTimer);
                        }

                        $scope.searching = true;

                        $scope.searchTimer = $timeout(function() {
                            $scope.searchTimerComplete($scope.searchStr);
                        }, $scope.pause);
                    }
                } else {
                    event.preventDefault();
                }
    }
     isNewSearchNeeded = function(newTerm, oldTerm) {
                return newTerm.length >= $scope.minLength && newTerm != oldTerm
            }
     $scope.searchTimerComplete = function(str) {
                // Begin the search
                if (str.length >= $scope.minLength) {
                 $http({
                      method: 'GET',
                      url: config.apiURL+'search-location?location=' + str
                   }).then(function (response){
                         data = response.data;
                         if(data.status == 200){
                          $scope.searching = false;
                          responseData = data.data;
                          $scope.processResults((($scope.dataField) ? responseData[$scope.dataField] : responseData ), str);
                         }
                           },function (error){
                                 console.log("error");
                    });
                }
            }
     $scope.processResults = function(responseData, str) {

                if (responseData && responseData.length > 0) {
                    $scope.results = [];

                    var titleFields = [];
                    if ($scope.titleField && $scope.titleField != "") {
                        titleFields = $scope.titleField.split(",");
                    }
                    for (var i = 0; i < responseData.length; i++) {
                        // Get title variables
                        var titleCode = [];
                        
                        for (var t = 0; t < titleFields.length; t++) {
                            titleCode.push(responseData[i][titleFields[t]]);
                        }
                        var text = titleCode.join(' ');
                        if ($scope.matchClass) {
                            var re = new RegExp(str, 'i');
                            var strPart = text.match(re)[0];
                            text = $sce.trustAsHtml(text.replace(re, '<span class="'+ $scope.matchClass +'">'+ strPart +'</span>'));
                        }

                        var resultRow = {
                             title: text,
                            originalObject: responseData[i]
                        }
                        $scope.results[$scope.results.length] = resultRow;
                    }


                } else {
                    $scope.results = [];
                }
            }
            
    $scope.selectResult = function(result) {
                if ($scope.matchClass) {
                    result.title = result.title.toString().replace(/(<([^>]+)>)/ig, '');
                }
                
                $scope.searchStr = $scope.lastSearchTerm = result.title;
                $scope.searchlocation = $scope.searchStr;
                if($scope.searchlocation !== ''){
                     $scope.clearfilter = true;
                     $scope.city_name = '';
                     $scope.state_name= '';
                }else{
                    $scope.clearfilter = false;
                }
                $scope.showDropdown = false;
                $scope.results = [];
               $scope.CallAPIRequest($scope.member_name,$scope.firm_name,$scope.designation_name,$scope.city_name,$scope.state_name.state_sort_name,$scope.services.toString(),$scope.searchlocation,$scope.currentPage);
                $location.path('filter-result',false).search('location_name', $scope.searchlocation).search('city_name', $scope.city_name).search('state_name', $scope.state_name);
    }
     $scope.clearcity = function(){
       $scope.results = [];
       $scope.searchlocation = '';
       $scope.searchStr = '';
       if( $scope.searchlocation == ''){
             $scope.clearfilter = false;
       }
       $scope.CallAPIRequest($scope.member_name,$scope.firm_name,$scope.designation_name,$scope.city_name,$scope.state_name.state_sort_name,$scope.services.toString(),$scope.searchlocation,$scope.currentPage);
        $location.path('filter-result',false).search('location_name', $scope.searchlocation);
    }
    $scope.hoverRow = function(index) {
                $scope.currentIndex = index;
            }
}
  
});
