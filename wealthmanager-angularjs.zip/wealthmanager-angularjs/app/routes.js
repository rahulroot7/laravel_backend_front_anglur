
var app = angular.module("myApp", ["ngRoute","ngSanitize","ui.bootstrap","underscore"]);

app.constant('config', {  
appName: 'Wealth Manager',  
apiURL: 'https://testcaresort.com/wealth_manager_bckend/api/',
siteURL: 'https://testcaresort.com/wealthmanager-angularjs/',
appVersion: 1.0  
}); 


app.config(function($routeProvider, $locationProvider) {
    $routeProvider
    .when("/", {
        templateUrl : "views/main.html",
        controller: 'HomeController'
    })
    .when("/join-advisor", {
        templateUrl : "views/join-advisor.html",
        controller: 'JoinadvisorController'
    })
    .when("/join-advisor-plan", {
        templateUrl : "views/join-advisor-plan.html",
        controller: 'JoinadvisorplanController'
    })
    .when("/search-result", {
        templateUrl : "views/search-result.html"
    })
    .when("/filter-result", {
        templateUrl : "views/filter-result.html",
        controller: 'FilterresultController',
    })
    .when("/single-profile/:id", {
        templateUrl : "views/single-profile.html",
        controller: 'SingleProfileController'
    })
    .when("/firm-detail/:id", {
        templateUrl : "views/firm-detail.html",
        controller: 'FirmdetailController'
    })
    .when("/cities", {
        templateUrl : "views/cities.html",
        controller: 'CitiesController'
    })
    .when("/login", {
        templateUrl : "views/login.html",
        controller: 'LoginController'
    })
    .when("/find-member", {
        templateUrl : "views/find-member.html",
        controller: 'FindMemberController'
    });
    
    // use the HTML5 History API
    $locationProvider.html5Mode(true);
});

app.run(['$route', '$rootScope', '$location', function ($route, $rootScope, $location,Session) {
    var original = $location.path;
    $location.path = function (path, reload) {
        if (reload === false) {
            var lastRoute = $route.current;
            var un = $rootScope.$on('$locationChangeSuccess', function () {
                $route.current = lastRoute;
                un();
            });
        }
        return original.apply($location, [path]);
    };
}])

app.factory('Session', function($http) {
  var Session = {
    data: {},
    saveSession: function() { /* save session data to db */ },
    updateSession: function() { 
      /* load data from db */
      $http.get('session.json')
        .then(function(r) { return Session.data = r.data;})
    }
  };
  Session.updateSession();
  return Session; 
});
