app.controller('FirmdetailController', function($scope,$http,config,$routeParams) {
 $scope.showLoader = true;
  $scope.noresult = false; 
$scope.opendetail = function (evt,activity) {
       var i, singlefirmtabcontent, singlefirmtablinks;
      singletabcontent = document.getElementsByClassName("singlefirmtabcontent");
      for (i = 0; i < singletabcontent.length; i++) {
        singletabcontent[i].style.display = "none";
      }
      singletablinks = document.getElementsByClassName("singlefirmtablinks");
      for (i = 0; i < singletablinks.length; i++) {
        singletablinks[i].className = singletablinks[i].className.replace(" active", "");
      }
      document.getElementById(activity).style.display = "block";
      evt.className += " active"; 
};


$http({
          method: 'GET',
          url:  config.apiURL+'single-firm-detail/'+$routeParams.id
       }).then(function (response){
             data = response.data;
             $scope.showLoader = false;
             if(data.status == 200){
                 if(data.data.length > 0){
                     $scope.firmdetail = data.data[0];
                     console.log(data.data[0]);
                 }else{
                     $scope.firmdetail = '';
                 }
                 
             }else{
                $scope.noresult = true; 
             }
             
       },function (error){
             console.log(error);
       });
});

