app.controller('JoinadvisorplanController', function($scope,$http,fileReader,config,_) {
$scope.selectedservices = [];
$scope.file = '';
$scope.myFirm = '';
$scope.formerror = false;
$scope.message = '';
$scope.formdata = {
    first_name :'',
    last_name :'',
    email :'',
    password :'',
    confirmpassword :'',
    mobile :'',
    address1 :'',
    country :'',
    state :'',
    city :'',
    postal_code :'',
    firm_name :'',
    myFirm :'',
    firm_list :'',
    services :[]
}
    $scope.servicessettings = {
        scrollableHeight: '250px',
        scrollable: true,
        enableSearch: true
    };
    
    $http({
          method: 'GET',
          url: config.apiURL+'show-plan/'
       }).then(function (response){
             data = response.data;
             if(data.status == 200){
                 $scope.plans = data.data;
             }
             
       },function (error){
             console.log(error);
       });
       
       $http({
          method: 'GET',
          url:  config.apiURL+'home-service-list'
       }).then(function (response){
             data = response.data;
             if(data.status == 200){
                 $scope.servicelist = data.data;
                 console.log($scope.servicelist);
             }else{
                 $scope.servicelist = [];
             }
       },function (error){
             console.log(error);
    });
    
     $http({
          method: 'GET',
          url:  config.apiURL+'all-country-list'
       }).then(function (response){
             data = response.data;
             if(data.status == 200){
                 $scope.countrylist = data.data;
             }else{
                 $scope.servicelist = [];
             }
       },function (error){
             console.log(error);
    });
    
    $http({
          method: 'GET',
          url:  config.apiURL+'firm-list'
       }).then(function (response){
             data = response.data;
             if(data.status == 200){
                 $scope.firmlist = data.data;
             }else{
                 $scope.firmlist = [];
             }
       },function (error){
             console.log(error);
    });
       
       $scope.addborder = function(evt,planId) {
            var i, selectplan;
            document.getElementById('planId').value = planId;
          selectplan = document.getElementsByClassName("select-plan");
          for (i = 0; i < selectplan.length; i++) {
            selectplan[i].className = selectplan[i].className.replace(" premium-plan", "");
          }
          evt.className += " premium-plan";
        
        }
    $scope.show_next = function (id,nextid,bar) {
        var ele = document.getElementById(id).getElementsByTagName("input");
        
          var error=0;
          if(error === 0)
          {
            document.getElementById("create_account").style.display="none";
            document.getElementById("user_details").style.display="none";
            document.getElementById("services_offer").style.display="none";
            document.getElementById("firm_detail").style.display="none";
            document.getElementById("select_plan").style.display="none";
            document.getElementById("sent_successfully").style.display="none";
            $("#"+nextid).fadeIn();
                document.getElementById(bar).style.backgroundColor="#68376e"; 
            }
          else
          {
            alert("Fill All The details");
          }
}

 $scope.show_prev = function (previd,bar) {
         document.getElementById("create_account").style.display="none";
          document.getElementById("user_details").style.display="none";
          document.getElementById("services_offer").style.display="none";
          document.getElementById("firm_detail").style.display="none";
          document.getElementById("select_plan").style.display="none";
          document.getElementById("sent_successfully").style.display="none";
          $("#"+previd).fadeIn();
       document.getElementById(bar).style.backgroundColor="#f2f2f2";
            
};

$scope.selectcountry = function() {
    $scope.statelist = [];
    $scope.citylist = [];
    $scope.statelist = [{"name":"Please Wait....."}];
      if ($scope.formdata.country) {
        var countryId =  JSON.parse($scope.formdata.country)
        $http({
              method: 'GET',
              url:  config.apiURL+'state-list-according-country/?country_id='+countryId.id
           }).then(function (response){
                  data = response.data;
                 if(data.status == 200){
                     $scope.statelist = data.data;
                    }else{
                    $scope.statelist = []; 
                    }
                 
           },function (error){
                 console.log(error);
        });
      }else{
           $scope.statelist = []; 
      }
    } 
$scope.selectstate = function() {
    $scope.citylist = [];
    $scope.citylist = [{"name":"Please Wait....."}];
      if ($scope.formdata.state) {
        var stateId =  JSON.parse($scope.formdata.state)
        $http({
              method: 'GET',
              url:  config.apiURL+'city-list-according-state?state_id='+stateId.id
           }).then(function (response){
                  data = response.data;
                 if(data.status == 200){
                     $scope.citylist = data.data;
                    }else{
                    $scope.citylist = []; 
                    }
                 
           },function (error){
                 console.log(error);
        });
      }else{
           $scope.citylist = []; 
      }
    } 
 $scope.phoneNumbr = /^(\([0-9]{3}\)|[0-9]{3}-)[0-9]{3}-[0-9]{4}$/;  
 
 $scope.imageSrc = "./images/img-upload1.png";
 $scope.firmimageSrc = "./images/img-upload2.png";

 $scope.getFile = function () {
        fileReader.readAsDataUrl($scope.file, $scope)
                      .then(function(result) {
                          $scope.imageSrc = result;
                      });
    };  
    
    $scope.getFirmFile = function () {
        fileReader.readAsDataUrl($scope.firmfile, $scope)
                      .then(function(result) {
                          $scope.firmimageSrc = result;
                      });
    };    


 $scope.submitAdvisorForm = function ($event) {
    $event.preventDefault();
    $scope.formdata.plan_id = document.getElementById('planId').value;
    console.log($scope.selectedservices);
if($scope.selectedservices.length > 0 )    
  angular.forEach($scope.selectedservices, function(value, key){
      $scope.formdata.services.push(value.id);
 });
 console.log($scope.formdata.services);
 var fd = new FormData();
  fd.append('email', $scope.formdata.email);
  fd.append('mobile', $scope.formdata.mobile);
  fd.append('first_name', $scope.formdata.first_name);
  fd.append('last_name', $scope.formdata.last_name);
  fd.append('address1', $scope.formdata.address1);
  var countrycode ='';
  var statecode = '';
  if($scope.formdata.country !== ''){
      var country = JSON.parse($scope.formdata.country);
      countrycode = country.sortname;
  }
   if($scope.formdata.state !== ''){
      var state = JSON.parse($scope.formdata.state);
      statecode = state.state_sort_name;
  }

  fd.append('country_code', countrycode);
  fd.append('state_code', statecode);
  fd.append('city', $scope.formdata.city);
  fd.append('postal_code', $scope.formdata.postal_code);
  fd.append('password', $scope.formdata.password);
  fd.append('plan_id', $scope.formdata.plan_id);
  fd.append('profile_pic[]', $scope.file);
  fd.append('firm_name', $scope.formdata.firm_name);
  if($scope.formdata.firm_name === 'Other'){
      fd.append('add_firm_logo[]', $scope.firmfile);
      fd.append('add_firm_name', $scope.formdata.firm_list);   
  }
 
  fd.append('services_list', $scope.formdata.services.toString());

         $http({
          method: 'POST',
          url: config.apiURL+'register-advisor',
          data: fd,
           headers: {
                        'Content-Type': undefined
                    }
       }).then(function (response){
             data = response.data;
              console.log( data);
             if(data.status == 200){
                 document.getElementById("select_plan").style.display="none";
                 document.getElementById("sent_successfully").style.display="block";
             }else{
                $scope.formerror = true;
                $scope.message = data.message;
             }
              
       },function (error){
             console.log(error);
            $scope.formerror = true;
            $scope.message = 'Something went wrong.';
       });
    };
    
    $scope.selectfirm=  function(firmname){
        $scope.formdata.firm_name = firmname;
    }
});

app.directive("compareTo", function ()  
{  
    return {  
        require: "ngModel",  
        scope:  
        {  
            confirmpassword: "=compareTo"  
        },  
        link: function (scope, element, attributes, modelVal)  
        {  
            modelVal.$validators.compareTo = function (val)  
            {  
                return val == scope.confirmpassword;  
            };  
            scope.$watch("confirmpassword", function ()  
            {  
                modelVal.$validate();  
            });  
        }  
    };  
}); 

app.directive("ngFileSelect",function(){
  return {
    link: function($scope,el){
      
      el.bind("change", function(e){
        $scope.file = (e.srcElement || e.target).files[0];
        $scope.getFile();
      })
      
    }
  }
})

app.directive("ngFirmFileSelect",function(){
  return {
    link: function($scope,el){
      
      el.bind("change", function(e){
        $scope.firmfile = (e.srcElement || e.target).files[0];
        $scope.getFirmFile();
      })
      
    }
  }
})

app.directive("ngDropdownMultiselect",['$filter', '$document', '$compile', '$parse',function($filter, $document, $compile, $parse){
  return {
    restrict: 'AE',
    scope: {
            selectedModel: '=',
            options: '=',
            extraSettings: '=',
            events: '=',
            searchFilter: '=?',
            translationTexts: '=',
            groupBy: '@'
        },
    template: function (element, attrs) {
            var checkboxes = attrs.checkboxes ? true : false;
            var groups = attrs.groupBy ? true : false;

            var template = '<div class="multiselect-parent btn-group dropdown-multiselect">';
            template += '<button type="button" class="dropdown-toggle" ng-class="settings.buttonClasses" ng-click="toggleDropdown()">{{getButtonText()}}&nbsp;<span class="caret"></span></button>';
            template += '<ul class="dropdown-menu dropdown-menu-form p-4" ng-style="{display: open ? \'block\' : \'none\', height : settings.scrollable ? settings.scrollableHeight : \'auto\' }" style="overflow: scroll" >';
            template += '<li ng-hide="!settings.showCheckAll || settings.selectionLimit > 0"><a data-ng-click="selectAll()" class="check-all-services"><i class="fa fa-check" aria-hidden="true"></i>  {{texts.checkAll}}</a>';
            template += '<li ng-show="settings.showUncheckAll"><a data-ng-click="deselectAll();" class="uncheck-all-services"><i class="fa fa-times" aria-hidden="true"></i>   {{texts.uncheckAll}}</a></li>';
            template += '<li ng-hide="(!settings.showCheckAll || settings.selectionLimit > 0) && !settings.showUncheckAll" class="divider"></li>';
            template += '<li ng-show="settings.enableSearch"><div class="dropdown-header"><input type="text" class="form-control primary-border my-3" style="width: 100%;" ng-model="searchFilter" placeholder="{{texts.searchPlaceholder}}" /></li>';
            template += '<li ng-show="settings.enableSearch" class="divider"></li>';

            if (groups) {
                template += '<li ng-repeat-start="option in orderedItems | filter: searchFilter" ng-show="getPropertyForObject(option, settings.groupBy) !== getPropertyForObject(orderedItems[$index - 1], settings.groupBy)" role="presentation" class="dropdown-header">{{ getGroupTitle(getPropertyForObject(option, settings.groupBy)) }}</li>';
                template += '<li ng-repeat-end role="presentation">';
            } else {
                template += '<li role="presentation" ng-repeat="option in options | filter: searchFilter">';
            }

            template += '<a role="menuitem" tabindex="-1" ng-click="setSelectedItem(getPropertyForObject(option,settings.idProp))">';

            if (checkboxes) {
                template += '<div class="checkbox"><label><input class="checkboxInput" type="checkbox" ng-click="checkboxClick($event, getPropertyForObject(option,settings.idProp))" ng-checked="isChecked(getPropertyForObject(option,settings.idProp))" /> {{getPropertyForObject(option, settings.displayProp)}}</label></div></a>';
            } else {
                template += '<span data-ng-class="{\'glyphicon glyphicon-ok\': isChecked(getPropertyForObject(option,settings.idProp))}"></span> {{getPropertyForObject(option, settings.displayProp)}}</a>';
            }

            template += '</li>';

            template += '<li class="divider" ng-show="settings.selectionLimit > 1"></li>';
            template += '<li role="presentation" ng-show="settings.selectionLimit > 1"><a role="menuitem">{{selectedModel.length}} {{texts.selectionOf}} {{settings.selectionLimit}} {{texts.selectionCount}}</a></li>';

            template += '</ul>';
            template += '</div>';

            element.html(template);
        },
    link: function ($scope, $element, $attrs) {
            var $dropdownTrigger = $element.children()[0];

            $scope.toggleDropdown = function () {
                $scope.open = !$scope.open;
            };

            $scope.checkboxClick = function ($event, id) {
                $scope.setSelectedItem(id);
                $event.stopImmediatePropagation();
            };

            $scope.externalEvents = {
                onItemSelect: angular.noop,
                onItemDeselect: angular.noop,
                onSelectAll: angular.noop,
                onDeselectAll: angular.noop,
                onInitDone: angular.noop,
                onMaxSelectionReached: angular.noop
            };

            $scope.settings = {
                dynamicTitle: true,
                scrollable: false,
                scrollableHeight: '300px',
                closeOnBlur: true,
                displayProp: 'name',
                idProp: 'id',
                externalIdProp: 'id',
                enableSearch: false,
                selectionLimit: 0,
                showCheckAll: true,
                showUncheckAll: true,
                closeOnSelect: false,
                buttonClasses: 'btn btn-default',
                closeOnDeselect: false,
                groupBy: $attrs.groupBy || undefined,
                groupByTextProvider: null,
                smartButtonMaxItems: 0,
                smartButtonTextConverter: angular.noop
            };

            $scope.texts = {
                checkAll: 'Check All',
                uncheckAll: 'Uncheck All',
                selectionCount: 'checked',
                selectionOf: '/',
                searchPlaceholder: 'Search...',
                buttonDefaultText: 'Select',
                dynamicButtonTextSuffix: 'checked'
            };

            $scope.searchFilter = $scope.searchFilter || '';

            if (angular.isDefined($scope.settings.groupBy)) {
                $scope.$watch('options', function (newValue) {
                    if (angular.isDefined(newValue)) {
                        $scope.orderedItems = $filter('orderBy')(newValue, $scope.settings.groupBy);
                    }
                });
            }

            angular.extend($scope.settings, $scope.extraSettings || []);
            angular.extend($scope.externalEvents, $scope.events || []);
            angular.extend($scope.texts, $scope.translationTexts);

            $scope.singleSelection = $scope.settings.selectionLimit === 1;

            function getFindObj(id) {
                var findObj = {};

                if ($scope.settings.externalIdProp === '') {
                    findObj[$scope.settings.idProp] = id;
                } else {
                    findObj[$scope.settings.externalIdProp] = id;
                }

                return findObj;
            }

            function clearObject(object) {
                for (var prop in object) {
                    delete object[prop];
                }
            }

            if ($scope.singleSelection) {
                if (angular.isArray($scope.selectedModel) && $scope.selectedModel.length === 0) {
                    clearObject($scope.selectedModel);
                }
            }

            if ($scope.settings.closeOnBlur) {
                $document.on('click', function (e) {
                    var target = e.target.parentElement;
                    var parentFound = false;

                    while (angular.isDefined(target) && target !== null && !parentFound) {
                        if (_.contains(target.className.split(' '), 'multiselect-parent') && !parentFound) {
                            if (target === $dropdownTrigger) {
                                parentFound = true;
                            }
                        }
                        target = target.parentElement;
                    }

                    if (!parentFound) {
                        $scope.$apply(function () {
                            $scope.open = false;
                        });
                    }
                });
            }

            $scope.getGroupTitle = function (groupValue) {
                if ($scope.settings.groupByTextProvider !== null) {
                    return $scope.settings.groupByTextProvider(groupValue);
                }

                return groupValue;
            };

            $scope.getButtonText = function () {
                if ($scope.settings.dynamicTitle && ($scope.selectedModel.length > 0 || (angular.isObject($scope.selectedModel) && _.keys($scope.selectedModel).length > 0))) {
                    if ($scope.settings.smartButtonMaxItems > 0) {
                        var itemsText = [];

                        angular.forEach($scope.options, function (optionItem) {
                            if ($scope.isChecked($scope.getPropertyForObject(optionItem, $scope.settings.idProp))) {
                                var displayText = $scope.getPropertyForObject(optionItem, $scope.settings.displayProp);
                                var converterResponse = $scope.settings.smartButtonTextConverter(displayText, optionItem);

                                itemsText.push(converterResponse ? converterResponse : displayText);
                            }
                        });

                        if ($scope.selectedModel.length > $scope.settings.smartButtonMaxItems) {
                            itemsText = itemsText.slice(0, $scope.settings.smartButtonMaxItems);
                            itemsText.push('...');
                        }

                        return itemsText.join(', ');
                    } else {
                        var totalSelected;

                        if ($scope.singleSelection) {
                            totalSelected = ($scope.selectedModel !== null && angular.isDefined($scope.selectedModel[$scope.settings.idProp])) ? 1 : 0;
                        } else {
                            totalSelected = angular.isDefined($scope.selectedModel) ? $scope.selectedModel.length : 0;
                        }

                        if (totalSelected === 0) {
                            return $scope.texts.buttonDefaultText;
                        } else {
                            return totalSelected + ' ' + $scope.texts.dynamicButtonTextSuffix;
                        }
                    }
                } else {
                    return $scope.texts.buttonDefaultText;
                }
            };

            $scope.getPropertyForObject = function (object, property) {
                if (angular.isDefined(object) && object.hasOwnProperty(property)) {
                    return object[property];
                }

                return '';
            };

            $scope.selectAll = function () {
                $scope.deselectAll(false);
                $scope.externalEvents.onSelectAll();

                angular.forEach($scope.options, function (value) {
                    $scope.setSelectedItem(value[$scope.settings.idProp], true);
                });
            };

            $scope.deselectAll = function (sendEvent) {
                sendEvent = sendEvent || true;

                if (sendEvent) {
                    $scope.externalEvents.onDeselectAll();
                }

                if ($scope.singleSelection) {
                    clearObject($scope.selectedModel);
                } else {
                    $scope.selectedModel.splice(0, $scope.selectedModel.length);
                }
            };

            $scope.setSelectedItem = function (id, dontRemove) {
                var findObj = getFindObj(id);
                var finalObj = null;

                if ($scope.settings.externalIdProp === '') {
                    finalObj = _.find($scope.options, findObj);
                } else {
                    finalObj = findObj;
                }

                if ($scope.singleSelection) {
                    clearObject($scope.selectedModel);
                    angular.extend($scope.selectedModel, finalObj);
                    $scope.externalEvents.onItemSelect(finalObj);
                    if ($scope.settings.closeOnSelect) $scope.open = false;

                    return;
                }

                dontRemove = dontRemove || false;

                var exists = _.findIndex($scope.selectedModel, findObj) !== -1;

                if (!dontRemove && exists) {
                    $scope.selectedModel.splice(_.findIndex($scope.selectedModel, findObj), 1);
                    $scope.externalEvents.onItemDeselect(findObj);
                } else if (!exists && ($scope.settings.selectionLimit === 0 || $scope.selectedModel.length < $scope.settings.selectionLimit)) {
                    $scope.selectedModel.push(finalObj);
                    $scope.externalEvents.onItemSelect(finalObj);
                }
                if ($scope.settings.closeOnSelect) $scope.open = false;
            };

            $scope.isChecked = function (id) {
                if ($scope.singleSelection) {
                    return $scope.selectedModel !== null && angular.isDefined($scope.selectedModel[$scope.settings.idProp]) && $scope.selectedModel[$scope.settings.idProp] === getFindObj(id)[$scope.settings.idProp];
                }

                return _.findIndex($scope.selectedModel, getFindObj(id)) !== -1;
            };

            $scope.externalEvents.onInitDone();
        }
  }
}])
