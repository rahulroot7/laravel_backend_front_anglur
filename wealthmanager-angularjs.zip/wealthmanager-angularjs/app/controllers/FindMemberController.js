app.controller('FindMemberController', function($scope,$http,config,$routeParams,$location) {
    $scope.services = [];
    $scope.showfilterLoader = true;  
    $scope.citylist = false;  
    $scope.city_name = '';  
    $scope.disabledFlag = true;
    
    init();
    function init() {
    $http({
              method: 'GET',
              url: config.apiURL+'home-service-list'
           }).then(function (response){
                  data = response.data;
                 if(data.status == 200){
                     $scope.servicelist = data.data;
                     console.log( $scope.servicelist);
                 }
                $scope.showfilterLoader = false;
           },function (error){
                $scope.showfilterLoader = false;
           }); 
           
    $scope.servicesadd = function ($event,$className,$member) {
     const hasClass = $event.currentTarget.classList.contains($className);
      if(hasClass) {
        $scope.services.pop($member);
        $event.currentTarget.className = 'main-btn mb-3 active_btn';
      } else {
          $scope.services.push($member);
         $event.currentTarget.className = 'main-btn mb-3 active_btn active_btn_active';
      }
      if($scope.services.length === 0){
           $scope.disabledFlag = true;
      }else{
           $scope.disabledFlag = false;
      }
    };
 
    $scope.showcity = function () {
    $scope.cityrw = true; 
    $scope.showfilterLoader = true;  
    $http({
              method: 'GET',
              url:  config.apiURL+'all-state-list'
           }).then(function (response){
                 data = response.data;
                 if(data.status == 200){
                     $scope.statelist = data.data;
                 }
               $scope.showfilterLoader = false;       
           },function (error){
                 console.log(error);
        }); 
     
    }; 
    
    $scope.callCitylist = function() {
    $scope.citylist = [];
    $scope.citylist = [{"name":"Please Wait....."}];
      if ($scope.state_name) {
        var state =  JSON.parse($scope.state_name)
        $http({
              method: 'GET',
              url:  config.apiURL+'city-list-according-state/?state_id='+state.id
           }).then(function (response){
                  data = response.data;
                 console.log(data);
                 if(data.status == 200){
                     $scope.citylist = data.data;
                    }else{
                    $scope.citylist = []; 
                    }
                 
           },function (error){
                 console.log(error);
        });
      }else{
           $scope.citylist = []; 
      }
    } 
    
    $scope.findAdvisor = function ($event) {
    var servicesStr = $scope.services.join(",");
     var state_name = '';
    if ($scope.state_name) {
        var state =  JSON.parse($scope.state_name);
        state_name = state.state_sort_name;
      }
     $location.path('filter-result/').search('service_name', servicesStr).search('city_name', $scope.city_name).search('state_name',state_name);
          
    };
           
    }

});