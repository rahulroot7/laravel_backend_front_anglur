app.controller('CitiesController', function($scope,$http,config,$routeParams,$location) {
    
  $scope.showLoader = true; 
  $scope.noresult = false; 
  
    $scope.filtercityresults = [];
    $scope.filtercitylist = [];

    $scope.currentPage = 1;   
    $scope.pageSize = 5;
    
    $scope.page = '';
    
      $scope.filtercitydata = {
        member_name:'',
        firm_name:'',
        city_name:''
    }
    
    init();
    
    function init() {
        if($routeParams.city !== undefined){
                 $scope.filtercitydata.city_name = $routeParams.city;
        } 
        if($routeParams.page !== undefined){
            $scope.page = $routeParams.page;
        }
        
        if($routeParams.member_name !== undefined){
                 $scope.filtercitydata.member_name = $routeParams.member_name;
        }
        if($routeParams.firm_name !== undefined){
                 $scope.filtercitydata.firm_name = $routeParams.firm_name;
        } 

    $scope.fetchdata = function($page){
      $scope.showLoader = true; 
         $http({
          method: 'GET',
          url:  config.apiURL+'city-filter-result?city_name='+$scope.filtercitydata.city_name+'&page='+$page
       }).then(function (response){
             data = response.data;
             console.log( data.data);
             if(data.status == 200){
                 if(data.data !== ''){
                     $scope.cityresults = data.data;
                     $scope.filtercityresults = data.data.member_data['0']['member_list'];
                     $scope.totalrecords = data.data.member_data['0']['member_list_total'];
                     $scope.pager = $scope.GetPager($scope.totalrecords,$page);
                 }else{
                     $scope.cityresults = [];
                 }
                 
             }else{
                $scope.noresult = true; 
             }
             $scope.showLoader = false;
       },function (error){
           $scope.showLoader = false;
             console.log(error);
       });
    }
    
   
    $http({
          method: 'GET',
          url:  config.apiURL+'all-city-list'
       }).then(function (response){
             data = response.data;
             if(data.status == 200){
                 if(data.data !== ''){
                     $scope.allcitieslist = data.data;
                     
                 }else{
                     $scope.allcitieslist = [];
                 }
                 
             }else{
               // $scope.noresult = true; 
             }
       },function (error){
             console.log(error);
       });
       
     $http({
          method: 'GET',
          url:  config.apiURL+'firm-list'
       }).then(function (response){
             data = response.data;
             if(data.status == 200){
                 if(data.data !== ''){
                     $scope.allfirmlist = data.data;
                     
                 }else{
                     $scope.allfirmlist = [];
                 }
                 
             }else{
               // $scope.noresult = true; 
             }
       },function (error){
             console.log(error);
       });
    
  
  
    $scope.callshowfilter = function($page){
    $http({
          method: 'GET',
          url:  config.apiURL+'show-advisor-firm-city-filter-result?city_name='+$scope.filtercitydata.city_name+'&advisor_name='+$scope.filtercitydata.member_name+'&firm_name='+$scope.filtercitydata.firm_name+'&page='+$page
       }).then(function (response){
             data = response.data;
             console.log(data);
             if(data.status == 200){
                 if(data.data !== ''){
                     $scope.filtercityresults = data.data.member_list;
                     $scope.totalrecords = data.data.member_list_total;
                     $scope.pager = $scope.GetPager($scope.totalrecords,$page);
                 }else{
                     $scope.filtercityresults = [];
                 }
                 
             }else{
                 $scope.filtercityresults =[];
               
             }
            $scope.showLoader = false;
       },function (error){
           $scope.showLoader = false;
             console.log(error);
       });
    }
    
    if($scope.page === 'home'){
        $scope.fetchdata($scope.currentPage); 
    }else{
        $scope.callshowfilter($scope.currentPage);
    }
    $scope.showfilterForm = function ($event) {
        $scope.showLoader = true;  
        $scope.page = 'filter';
        $scope.currentPage = 1;
        $scope.callshowfilter($scope.currentPage);
        $location.path('cities/',false).search('page','filter').search('firm_name',$scope.filtercitydata.firm_name).search('member_name',$scope.filtercitydata.member_name).search('city',$scope.filtercitydata.city_name);
    };
    
    
    
     $scope.clearall = function () {
        $scope.filtercitydata = {
            member_name:'',
            firm_name:'',
            city_name:''
        }
        if($routeParams.city !== undefined){
                 $scope.filtercitydata.city_name = $routeParams.city;
            }
        $http({
              method: 'GET',
              url:  config.apiURL+'show-advisor-firm-city-filter-result?city_name='+$scope.filtercitydata.city_name+'&page=1'
           }).then(function (response){
                 data = response.data;
                 if(data.status == 200){
                     if(data.data !== ''){
                          $scope.filtercityresults = data.data.member_list;
                     $scope.totalrecords = data.data.member_list_total;
                       
                     }else{
                         $scope.filtercityresults = [];
                     }
                     
                 }else{
                     $scope.filtercityresults =[];
                   
                 }
                $scope.showLoader = false;
           },function (error){
               $scope.showLoader = false;
                 console.log(error);
           });
    };
    
    /*********Pagination function start**********/
    $scope.numberOfPages= function(){
        return Math.ceil($scope.totalrecords/$scope.pageSize);                
    }
    
    $scope.setPage = function($page){
         $scope.showLoader = true; 
         if ($page < 1 || $page > $scope.numberOfPages()) {
                return;
            }
        $scope.currentPage = $page; 
        console.log($page);
        console.log($scope.page);
       if($scope.page == 'home'){
            $scope.fetchdata($scope.currentPage);
        }else{
            $scope.callshowfilter($scope.currentPage);
        }
    }
    
    $scope.range = function(min, max, step){
        step = step || 1;
        var input = [];
        for (var i = min; i <= max; i += step) input.push(i);
        return input;
      };
    $scope.GetPager = function(totalItems, currentPage, pageSize){
         // default to first page
            currentPage = currentPage || 1;

            // default page size is 10
            pageSize = pageSize || 5;

            // calculate total pages
            var totalPages = Math.ceil(totalItems / pageSize);
            console.log(totalPages);
            var startPage, endPage;
            if (totalPages <= 10) {
                // less than 10 total pages so show all
                startPage = 1;
                endPage = totalPages;
            } else {
                // more than 10 total pages so calculate start and end pages
                if (currentPage <= 6) {
                    startPage = 1;
                    endPage = 10;
                } else if (currentPage + 4 >= totalPages) {
                    startPage = totalPages - 9;
                    endPage = totalPages;
                } else {
                    startPage = currentPage - 5;
                    endPage = currentPage + 4;
                }
            }

            // calculate start and end item indexes
            var startIndex = (currentPage - 1) * pageSize;
            var endIndex = Math.min(startIndex + pageSize - 1, totalItems - 1);

            // create an array of pages to ng-repeat in the pager control
            var pages = $scope.range(startPage, endPage );

            // return object with all pager properties required by the view
            return {
                totalItems: totalItems,
                currentPage: currentPage,
                pageSize: pageSize,
                totalPages: totalPages,
                startPage: startPage,
                endPage: endPage,
                startIndex: startIndex,
                endIndex: endIndex,
                pages: pages
            };
        }
   /*********Pagination function End**********/
    }
    
    
 
});