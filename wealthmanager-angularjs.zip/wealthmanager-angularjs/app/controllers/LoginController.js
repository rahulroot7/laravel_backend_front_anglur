app.controller('LoginController', function($scope,$http,config,$routeParams) {
    
    $scope.formerror =false;
    $scope.message ='';
   $scope.submitloginForm = function ($event) {
    $event.preventDefault();
    var strg = 'email='+$scope.formdata.email+'&password='+$scope.formdata.password;
       $http({
          method: 'POST',
          url: config.apiURL+'login-advisor?'+strg,
       }).then(function (response){
             data = response.data;
              console.log( data);
             if(data.status == 200){
               
             }else{
                $scope.formerror = true;
                $scope.message = data.message;
             }
              
       },function (error){
             console.log(error);
            $scope.formerror = true;
            $scope.message = 'Something went wrong.';
       });
    };
  

});
