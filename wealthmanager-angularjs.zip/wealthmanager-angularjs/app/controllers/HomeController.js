app.controller('HomeController', function($scope,$http,config,$location) {
     $scope.showServicesLoader = true;
     $scope.showexploreLoader = true;
    
     $scope.openCity = function (evt, cityName) {
        var i, tabcontent, tablinks;
         $scope.showexploreLoader = true;
        $scope.SwitchFuction(cityName);
      tabcontent = document.getElementsByClassName("tabcontent");
      for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
      }
      tablinks = document.getElementsByClassName("tablinks");
      for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
      }
      document.getElementById(cityName).style.display = "block";
      evt.className += " active";
};
   $scope.show_next = function (id,nextid,bar) {
        var ele = document.getElementById(id).getElementsByTagName("input");
          var error=0;
          if(error === 0)
          {
            document.getElementById("create_account").style.display="none";
            document.getElementById("user_details").style.display="none";
            document.getElementById("services_offer").style.display="none";
            document.getElementById("firm_detail").style.display="none";
            document.getElementById("select_plan").style.display="none";
            $("#"+nextid).fadeIn();
            document.getElementById(bar).style.backgroundColor="#38610B";
          }
          else
          {
            alert("Fill All The details");
          }
};

 $scope.show_prev = function (previd,bar) {
         document.getElementById("create_account").style.display="none";
          document.getElementById("user_details").style.display="none";
          document.getElementById("services_offer").style.display="none";
          document.getElementById("firm_detail").style.display="none";
          document.getElementById("select_plan").style.display="none";
          $("#"+previd).fadeIn();
          document.getElementById(bar).style.backgroundColor="#D8D8D8";
};

$http({
          method: 'GET',
          url:  config.apiURL+'home-service-list'
       }).then(function (response){
             data = response.data;
             if(data.status == 200){
                 $scope.homeservicelist = data.data;
             }
             $scope.showServicesLoader = false;
       },function (error){
             console.log(error);
    });
    
$http({
          method: 'GET',
          url:  config.apiURL+'all-state-list'
       }).then(function (response){
             data = response.data;
             if(data.status == 200){
                 $scope.statelist = data.data;
             }
             
       },function (error){
             console.log(error);
    });

$scope.setCitySelection = function() {
     $scope.citylist = [];
    $scope.citylist = [{"name":"Please Wait....."}];
      if ($scope.formdata.state_name) {
        var state =  JSON.parse($scope.formdata.state_name)
        $http({
              method: 'GET',
              url:  config.apiURL+'city-list-according-state/?state_id='+state.id
           }).then(function (response){
                  data = response.data;
                 console.log(data);
                 if(data.status == 200){
                     $scope.citylist = data.data;
                    }else{
                    $scope.citylist = []; 
                    }
                 
           },function (error){
                 console.log(error);
        });
      }else{
           $scope.citylist = []; 
      }
    }  
$scope.SwitchFuction = function(caseStr) {
        switch (caseStr) {
        case 'topwealth':
         $scope.topadvisor();
            break;
          case 'Cities':
          $scope.topcity();
            break;
          case 'Firms':
            $scope.topfirm();
            break;
          default:
            $scope.topadvisor();
            break;

        }
      };
       
$scope.topcity = function() {
      $http({
          method: 'GET',
          url:  config.apiURL+'top-city-list'
       }).then(function (response){
            $scope.showexploreLoader = false;
             data = response.data;
             if(data.status == 200){
                 $scope.topcitylist = data.data;
             }
             
       },function (error){
             console.log(error);
       });
}
$scope.topfirm = function() {
            $http({
                  method: 'GET',
                  url:  config.apiURL+'firm-list'
               }).then(function (response){
                    $scope.showexploreLoader = false;
                     data = response.data;
                     if(data.status == 200){
                         $scope.topfirms = data.data;
                     }
                     
               },function (error){
                     console.log(error);
               });
}

$scope.topadvisor = function() {
        $http({
              method: 'GET',
              url: config.apiURL+'advisor-list'
           }).then(function (response){
                 data = response.data;
                 $scope.showexploreLoader = false;
                 if(data.status == 200){
                     $scope.topwealthmanagers = data.data;
                 }
                 
           },function (error){
                 console.log(error);
           });
}

 $scope.SwitchFuction('topwealth');

 $scope.submitFilterForm = function ($event) {
     console.log($scope.formdata);
    $event.preventDefault();
    if($scope.formdata === undefined){
       $location.path('find-member/') ;
    }else{
    var state_name = '';
      if ($scope.formdata.state_name) {
        var state =  JSON.parse($scope.formdata.state_name);
        state_name = state.state_sort_name;
      }
    $location.path('filter-result').search('service_name', $scope.formdata.service_name).search('city_name', $scope.formdata.city_name).search('state_name', state_name);
 
    }

    };


});